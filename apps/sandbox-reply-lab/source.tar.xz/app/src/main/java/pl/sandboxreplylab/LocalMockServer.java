package pl.sandboxreplylab;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Minimal localhost-only, single-request-per-connection HTTP sandbox. */
public final class LocalMockServer {
    public interface EventListener { void onDecision(String path, String productId, String decision); }
    private static final Pattern PRODUCT = Pattern.compile("^\\{\\s*\"productId\"\\s*:\\s*\"([A-Za-z0-9_.-]{1,64})\"\\s*\\}$");
    private static final int MAX_HEADER_BYTES = 8192;
    private static final int MAX_BODY_BYTES = 4096;
    private final MockDecisionEngine engine;
    private final EventListener listener;
    private final int configuredPort;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private volatile ServerSocket serverSocket;
    private volatile Thread acceptThread;

    public LocalMockServer(MockDecisionEngine engine, int port, EventListener listener) {
        this.engine = engine;
        this.configuredPort = port;
        this.listener = listener;
    }

    public synchronized void start() throws IOException {
        if (running.get()) return;
        ServerSocket socket = new ServerSocket();
        socket.setReuseAddress(true);
        socket.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), configuredPort));
        socket.setSoTimeout(250);
        serverSocket = socket;
        running.set(true);
        acceptThread = new Thread(this::acceptLoop, "sandbox-local-http");
        acceptThread.setDaemon(true);
        acceptThread.start();
    }

    public synchronized void stop() {
        running.set(false);
        ServerSocket socket = serverSocket;
        serverSocket = null;
        if (socket != null) {
            try { socket.close(); } catch (IOException ignored) { }
        }
    }

    public boolean isRunning() { return running.get(); }
    public int getPort() {
        ServerSocket socket = serverSocket;
        return socket == null ? -1 : socket.getLocalPort();
    }

    private void acceptLoop() {
        while (running.get()) {
            try (Socket client = serverSocket.accept()) {
                client.setSoTimeout(2000);
                handle(client);
            } catch (SocketTimeoutException ignored) {
                // Periodic check for shutdown.
            } catch (IOException ignored) {
                if (!running.get()) return;
                // Broken client does not stop the sandbox.
            } catch (RuntimeException ignored) {
                // Malformed request does not stop the sandbox.
            }
        }
    }

    private void handle(Socket client) throws IOException {
        InputStream in = new BufferedInputStream(client.getInputStream());
        OutputStream out = client.getOutputStream();
        int[] headerBudget = {MAX_HEADER_BYTES};
        String requestLine = readLine(in, headerBudget);
        if (requestLine == null || !requestLine.matches("[A-Z]+ \\/?[^ ]* HTTP/1\\.[01]")) {
            respond(out, 400, "BAD_REQUEST", "Invalid HTTP request");
            return;
        }
        String[] parts = requestLine.split(" ", 3);
        String method = parts[0];
        String path = parts[1];
        int contentLength = -1;
        String line;
        while ((line = readLine(in, headerBudget)) != null && !line.isEmpty()) {
            int colon = line.indexOf(':');
            if (colon <= 0) { respond(out, 400, "BAD_REQUEST", "Malformed header"); return; }
            String key = line.substring(0, colon).trim();
            String value = line.substring(colon + 1).trim();
            if ("Transfer-Encoding".equalsIgnoreCase(key)) {
                respond(out, 400, "BAD_REQUEST", "Chunked transfer not supported"); return;
            }
            if ("Content-Length".equalsIgnoreCase(key)) {
                try { contentLength = Integer.parseInt(value); }
                catch (NumberFormatException ex) { respond(out, 400, "BAD_REQUEST", "Invalid body length"); return; }
            }
        }
        if (line == null) { respond(out, 400, "BAD_REQUEST", "Headers incomplete"); return; }
        if (!"POST".equals(method)) { respond(out, 405, "METHOD_NOT_ALLOWED", "Use POST"); return; }
        if (!"/sandbox/purchase".equals(path)) { respond(out, 404, "NOT_FOUND", "Endpoint not found"); return; }
        if (contentLength <= 0 || contentLength > MAX_BODY_BYTES) {
            respond(out, 400, "BAD_REQUEST", "Body size out of range"); return;
        }
        byte[] data = new byte[contentLength];
        int read = 0;
        while (read < contentLength) {
            int n = in.read(data, read, contentLength - read);
            if (n < 0) { respond(out, 400, "BAD_REQUEST", "Body truncated"); return; }
            read += n;
        }
        String body = new String(data, StandardCharsets.UTF_8).trim();
        if (!body.startsWith("{") || !body.endsWith("}")) {
            respond(out, 400, "BAD_REQUEST", "Expected JSON object"); return;
        }
        Matcher matcher = PRODUCT.matcher(body);
        if (!matcher.matches()) {
            respond(out, 400, "BAD_REQUEST", "Missing productId"); return;
        }
        String productId = matcher.group(1);
        try {
            MockDecisionEngine.Decision decision = engine.decide(productId);
            byte[] payload = decision.toJson().getBytes(StandardCharsets.UTF_8);
            writeResponse(out, 200, "OK", payload);
            if (listener != null) listener.onDecision(path, productId, decision.decision);
        } catch (IllegalArgumentException ex) {
            respond(out, 400, "BAD_REQUEST", "Invalid demo productId");
        }
    }

    private static String readLine(InputStream in, int[] remaining) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        while (true) {
            int b = in.read();
            if (b == -1) return null;
            if (--remaining[0] < 0) throw new IOException("Request headers too long");
            if (b == '\n') break;
            if (b != '\r') bytes.write(b);
        }
        return bytes.toString("UTF-8");
    }

    private static void respond(OutputStream out, int code, String reason, String message) throws IOException {
        String escaped = message.replace("\\", "\\\\").replace("\"", "\\\"");
        writeResponse(out, code, reason, ("{\"sandbox\":true,\"error\":\"" + escaped + "\"}")
                .getBytes(StandardCharsets.UTF_8));
    }
    private static void writeResponse(OutputStream out, int status, String reason, byte[] payload) throws IOException {
        String headers = "HTTP/1.1 " + status + " " + reason + "\r\n" +
                "Content-Type: application/json; charset=utf-8\r\n" +
                "Cache-Control: no-store\r\n" +
                "X-Sandbox-Only: true\r\n" +
                "Connection: close\r\n" +
                "Content-Length: " + payload.length + "\r\n\r\n";
        out.write(headers.getBytes(StandardCharsets.US_ASCII));
        out.write(payload);
        out.flush();
    }
}
