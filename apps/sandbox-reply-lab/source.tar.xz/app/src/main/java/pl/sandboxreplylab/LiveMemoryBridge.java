package pl.sandboxreplylab;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/**
 * Opt-in loopback debug interface between developer-owned Android apps.
 * Exported bytes are ONLY those explicitly provided by Target.snapshot(), not
 * arbitrary process memory. Never enable in a production application build.
 */
public final class LiveMemoryBridge {
    private static final int MAX_SNAPSHOT = 4 * 1024 * 1024;
    private static final int MAX_HEADERS = 12 * 1024;
    private LiveMemoryBridge() { }

    public static final class Client implements LiveMemoryScanner.Target {
        private final String url;
        private final String token;
        public Client(String host, int port, String token) {
            if (!"127.0.0.1".equals(host) && !"localhost".equals(host))
                throw new IllegalArgumentException("Dozwolony jest wyłącznie localhost");
            if (port < 1 || port > 65535 || token == null || token.length() < 12)
                throw new IllegalArgumentException("Nieprawidłowy port lub token debug");
            this.url = "http://127.0.0.1:" + port;
            this.token = token;
        }
        @Override public byte[] snapshot() {
            return request("GET", "/snapshot", null, MAX_SNAPSHOT);
        }
        @Override public void write(int offset, LiveMemoryScanner.Kind kind, String value) {
            if (offset < 0 || kind == null || value == null)
                throw new IllegalArgumentException("Nieprawidłowy zapis debug");
            String payload = offset + "\n" + kind.name() + "\n" + value;
            request("POST", "/write", payload.getBytes(StandardCharsets.UTF_8), 256);
        }
        private byte[] request(String verb, String route, byte[] payload, int limit) {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(url + route).openConnection();
                connection.setConnectTimeout(2000);
                connection.setReadTimeout(2500);
                connection.setRequestMethod(verb);
                connection.setRequestProperty("X-Debug-Token", token);
                if (payload != null) {
                    connection.setDoOutput(true);
                    connection.setFixedLengthStreamingMode(payload.length);
                    try (OutputStream out = connection.getOutputStream()) { out.write(payload); }
                }
                int code = connection.getResponseCode();
                if (code != 200) throw new IOException("Serwer debug zwrócił HTTP " + code);
                try (InputStream in = connection.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    byte[] b = new byte[8192]; int count;
                    while ((count = in.read(b)) != -1) {
                        if (out.size() + count > limit) throw new IOException("Odpowiedź debug przekracza limit");
                        out.write(b, 0, count);
                    }
                    return out.toByteArray();
                }
            } catch (IOException e) {
                throw new IllegalStateException("Połączenie debug: " + e.getMessage(), e);
            } finally { if (connection != null) connection.disconnect(); }
        }
    }

    public static final class Server implements AutoCloseable {
        private final LiveMemoryScanner.Target target;
        private final String token;
        private final ServerSocket socket;
        private Thread thread;
        private volatile boolean running;
        public Server(LiveMemoryScanner.Target target, int port, String token) throws IOException {
            if (target == null || token == null || token.length() < 12 || token.length() > 200)
                throw new IllegalArgumentException("Wymagany jest bufor debug i token 12–200 znaków");
            this.target = target;
            this.token = token;
            socket = new ServerSocket();
            socket.setReuseAddress(true);
            socket.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), port));
        }
        public int getPort() { return socket.getLocalPort(); }
        public synchronized void start() {
            if (thread != null) return;
            running = true;
            thread = new Thread(() -> {
                while (running) {
                    try (Socket client = socket.accept()) {
                        client.setSoTimeout(3000);
                        handle(client);
                    } catch (IOException ignored) { if (!running) break; }
                    catch (RuntimeException ignored) { /* Bad request must not kill the debug server. */ }
                }
            }, "sandbox-debug-loopback");
            thread.setDaemon(true);
            thread.start();
        }
        private void handle(Socket client) throws IOException {
            BufferedInputStream in = new BufferedInputStream(client.getInputStream());
            OutputStream out = client.getOutputStream();
            String requestLine = readLine(in);
            if (requestLine == null) return;
            int headerBytes = requestLine.length();
            String authorization = "";
            int length = 0;
            String line;
            while ((line = readLine(in)) != null && !line.isEmpty()) {
                headerBytes += line.length();
                if (headerBytes > MAX_HEADERS) { respond(out, 413, new byte[0]); return; }
                int colon = line.indexOf(':');
                if (colon < 0) { respond(out, 400, new byte[0]); return; }
                String key = line.substring(0, colon).trim();
                String value = line.substring(colon + 1).trim();
                if (key.equalsIgnoreCase("X-Debug-Token")) authorization = value;
                if (key.equalsIgnoreCase("Content-Length")) {
                    try { length = Integer.parseInt(value); }
                    catch (NumberFormatException bad) { respond(out, 400, new byte[0]); return; }
                }
            }
            if (!MessageDigest.isEqual(token.getBytes(StandardCharsets.UTF_8), authorization.getBytes(StandardCharsets.UTF_8))) {
                respond(out, 403, new byte[0]); return;
            }
            if ("GET /snapshot HTTP/1.1".equals(requestLine)) {
                byte[] bytes = target.snapshot();
                if (bytes.length > MAX_SNAPSHOT) { respond(out, 413, new byte[0]); return; }
                respond(out, 200, bytes);
            } else if ("POST /write HTTP/1.1".equals(requestLine)) {
                if (length <= 0 || length > 256) { respond(out, 413, new byte[0]); return; }
                byte[] body = new byte[length];
                try { new DataInputStream(in).readFully(body); }
                catch (EOFException bad) { respond(out, 400, new byte[0]); return; }
                String[] fields = new String(body, StandardCharsets.UTF_8).split("\\n", -1);
                if (fields.length != 3) { respond(out, 400, new byte[0]); return; }
                try {
                    int offset = Integer.parseInt(fields[0]);
                    LiveMemoryScanner.Kind kind = LiveMemoryScanner.Kind.valueOf(fields[1]);
                    target.write(offset, kind, fields[2]);
                    respond(out, 200, "OK".getBytes(StandardCharsets.US_ASCII));
                } catch (RuntimeException bad) { respond(out, 400, new byte[0]); }
            } else respond(out, 404, new byte[0]);
        }
        private static String readLine(InputStream in) throws IOException {
            ByteArrayOutputStream line = new ByteArrayOutputStream();
            int b;
            while ((b = in.read()) != -1) {
                if (b == '\n') break;
                if (b != '\r') line.write(b);
                if (line.size() > MAX_HEADERS) throw new IOException("Nagłówek za długi");
            }
            if (b == -1 && line.size() == 0) return null;
            return line.toString("UTF-8");
        }
        private static void respond(OutputStream out, int status, byte[] body) throws IOException {
            String label = status == 200 ? "OK" : status == 403 ? "Forbidden" : "Error";
            String header = "HTTP/1.1 " + status + " " + label + "\r\nContent-Type: application/octet-stream\r\n" +
                    "Content-Length: " + body.length + "\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n";
            out.write(header.getBytes(StandardCharsets.US_ASCII));
            out.write(body);
            out.flush();
        }
        @Override public synchronized void close() throws IOException {
            running = false;
            socket.close();
        }
    }
}
