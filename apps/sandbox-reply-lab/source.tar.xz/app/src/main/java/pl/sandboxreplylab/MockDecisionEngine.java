package pl.sandboxreplylab;

import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Pattern;

/** Only simulated local test results. Does not interact with Google Play Billing. */
public final class MockDecisionEngine {
    public enum Mode { APPROVE, DENY, ERROR }
    private static final Pattern VALID_ID = Pattern.compile("[A-Za-z0-9_.-]{1,64}");
    private final AtomicReference<Mode> mode = new AtomicReference<>(Mode.DENY);

    public Mode getMode() { return mode.get(); }
    public void setMode(Mode next) {
        if (next == null) throw new IllegalArgumentException("mode is required");
        mode.set(next);
    }

    public Decision decide(String productId) {
        if (productId == null || !VALID_ID.matcher(productId).matches() || productId.contains("..")) {
            throw new IllegalArgumentException("Invalid demo product identifier");
        }
        String result;
        switch (mode.get()) {
            case APPROVE: result = "APPROVED"; break;
            case ERROR: result = "ERROR"; break;
            default: result = "DECLINED"; break;
        }
        return new Decision(productId, result);
    }

    public static final class Decision {
        public final String productId;
        public final String decision;
        Decision(String productId, String decision) {
            this.productId = productId;
            this.decision = decision;
        }
        public String toJson() {
            return "{\"sandbox\":true,\"productId\":\"" + productId +
                    "\",\"decision\":\"" + decision +
                    "\",\"message\":\"Simulation only; no purchase or license issued\"}";
        }
    }
}
