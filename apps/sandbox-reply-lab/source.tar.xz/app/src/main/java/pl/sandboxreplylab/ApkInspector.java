package pl.sandboxreplylab;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

/** Bounded, offline, read-only archive and DEX *symbol* inventory. Does not execute or modify APK. */
public final class ApkInspector {
    private static final int MAX_FINDINGS = 220;
    private static final long MAX_TOTAL_BYTES = 90L * 1024 * 1024;
    private static final int MAX_TEXT_ENTRY = 768 * 1024;
    private static final int MAX_DEX_ENTRY = 36 * 1024 * 1024;
    private static final int MAX_NESTED_APK = 70 * 1024 * 1024;
    private static final int MAX_ENTRIES = 12000;
    private static final String[] KEYS = {
      "WALUTA:currency|currencies|coin|coins|gem|gems|diamond|diamonds|wallet|gold|credits|softcurrency|hardcurrency|balance|walut|saldo",
      "REKLAMY:advert|ads|adsdk|admob|adview|interstitial|rewardedad|rewarded_ad|unityads|adunit|appopenad|adrequest|com/google/android/gms/ads",
      "PŁATNOŚCI:billing|inapp|in_app|purchase|purchases|subscription|payment|productdetails|entitlement|iap|receipt|playbilling|sku",
      "BONUSY:dailyreward|daily_reward|bonus|bonuses|streak|gift|claimreward|claim_reward|achievement|loginreward|login_reward|reward",
      "ZAPIS:sharedpreferences|playerprefs|datastore|sqlite|roomdatabase|firestore|firebase/database|savegame|save_game|savedata|persistentdata|save_data"
    };
    private ApkInspector() { }

    public static final class Finding {
        public final String category, kind, location, name, meaning;
        Finding(String category, String kind, String location, String name, String meaning) {
            this.category=category; this.kind=kind; this.location=location; this.name=name; this.meaning=meaning;
        }
    }
    /** Indexed DEX symbol; a method reference is not proof that the method has code in this APK. */
    public static final class CatalogSymbol {
        public final String kind, name, location;
        CatalogSymbol(String kind, String name, String location) {
            this.kind = kind; this.name = name; this.location = location;
        }
    }
    public static final class Report {
        public final List<Finding> findings = new ArrayList<>();
        public final List<String> packageFiles = new ArrayList<>();
        public final LinkedHashSet<String> packageNames = new LinkedHashSet<>();
        public final List<String> methodSamples = new ArrayList<>();
        public final List<String> notes = new ArrayList<>();
        public final List<CatalogSymbol> catalog = new ArrayList<>();
        private static final int MAX_CATALOG = 18000;
        public List<CatalogSymbol> searchCatalog(String query, String scope, int limit) {
            String key = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
            String category = scope == null ? "ALL" : scope.trim().toUpperCase(Locale.ROOT);
            ArrayList<CatalogSymbol> result = new ArrayList<>();
            if (limit <= 0) return result;
            for (CatalogSymbol symbol : catalog) {
                if (!symbol.name.toLowerCase(Locale.ROOT).contains(key)) continue;
                if ("KLASY".equals(category) && !symbol.kind.startsWith("Klasa")) continue;
                if ("METODY".equals(category) && symbol.kind.startsWith("Klasa")) continue;
                if (!"ALL".equals(category) && !"KLASY".equals(category)
                        && !"METODY".equals(category) && !classify(symbol.name).contains(category)) continue;
                result.add(symbol);
                if (result.size() >= Math.min(limit, 250)) break;
            }
            return result;
        }
        private void catalogAdd(String kind, String name, String location) {
            if (catalog.size() < MAX_CATALOG) catalog.add(new CatalogSymbol(kind, name, location));
        }
        public int archiveCount, entriesScanned, dexCount, methodCount, classCount;
        private long scannedBytes;
        private final HashSet<String> seen = new HashSet<>();
        public String toText() {
            StringBuilder out = new StringBuilder(16_000);
            out.append("ANALIZA APK/XAPK — tryb tylko do odczytu\n")
               .append("Analiza statyczna: ślady w pakiecie, nie bieżące dane konta ani potwierdzone przepływy.\n")
               .append("Pakiety APK: ").append(archiveCount).append(" | DEX: ").append(dexCount)
               .append(" | identyfikatory metod: ").append(methodCount).append(" | klasy: ").append(classCount)
               .append(" | wpisy ZIP: ").append(entriesScanned).append("\n\n");
            for (String pack : packageFiles) out.append("PAKIET: ").append(pack).append('\n');
            for (String category : new String[]{"WALUTA", "REKLAMY", "PŁATNOŚCI", "BONUSY", "ZAPIS"}) {
                out.append("\n--- ").append(category).append(" ---\n");
                int count = 0;
                for (Finding item : findings) if (category.equals(item.category)) {
                    out.append("• ").append(item.name).append("\n  ").append(item.kind).append(" · ")
                       .append(item.location).append("\n  ").append(item.meaning).append("\n");
                    count++;
                }
                if (count == 0) out.append("Nie odnaleziono dopasowanych nazw w przeanalizowanym zakresie.\n");
            }
            out.append("\n--- WYSZUKIWARKA OFFLINE ---\n");
            out.append("Indeks katalogu: ").append(catalog.size()).append(" symboli (limit 18 000).\n");
            out.append("Metody zdefiniowane są rozróżniane od samych odwołań, jeśli class_data DEX jest poprawne.\n");
            out.append("\n--- KATALOG PAKIETÓW/KLAS (próbka, do 80) ---\n");
            if (packageNames.isEmpty()) out.append("Brak odczytanych definicji klas DEX.\n");
            else for (String className : packageNames) out.append("• ").append(className).append('\n');
            out.append("\n--- KATALOG METOD (próbka, do 120) ---\n");
            if (methodSamples.isEmpty()) out.append("Brak odczytanych identyfikatorów metod.\n");
            else for (String name : methodSamples) out.append("• ").append(name).append('\n');
            out.append("\nOGRANICZENIA\n");
            for (String note : notes) out.append("• ").append(note).append('\n');
            out.append("• Nazwa metody lub zasobu tylko sugeruje funkcję. Potwierdzenie wymaga analizy kodu i przepływu danych (np. REA + JADX).\n")
               .append("• Nie odczytano prywatnych danych aplikacji, salda na serwerze ani historii zakupów użytkownika.\n");
            return out.toString();
        }
        private void add(String category, String kind, String location, String symbol) {
            if (findings.size() >= MAX_FINDINGS) return;
            if (symbol.length() > 190) symbol = symbol.substring(0, 190);
            String identity = category + "|" + location + "|" + kind + "|" + symbol;
            if (!seen.add(identity)) return;
            String meaning;
            switch(category) {
                case "WALUTA": meaning="Możliwa nazwa mechanizmu lub zasobu waluty. To nie jest odczyt salda."; break;
                case "REKLAMY": meaning="Możliwa integracja SDK reklam lub logika reklam nagradzanych."; break;
                case "PŁATNOŚCI": meaning="Możliwa integracja rozliczeń, zakupów lub subskrypcji; uprawnienie może być weryfikowane na serwerze."; break;
                case "BONUSY": meaning="Możliwy bonus, system nagród lub warunek otrzymania nagrody."; break;
                default: meaning="Możliwy mechanizm trwałego zapisu, bez potwierdzenia nazwy pliku ani danych użytkownika.";
            }
            findings.add(new Finding(category, kind, location, symbol, meaning));
        }
    }
    public static List<String> classify(String symbol) {
        String normalized = symbol.toLowerCase(Locale.ROOT).replace("-", "_");
        List<String> result = new ArrayList<>();
        for (String row : KEYS) {
            String[] parts = row.split(":",2);
            for (String token : parts[1].split("\\|")) {
                if (normalized.contains(token)) { result.add(parts[0]); break; }
            }
        }
        return result;
    }
    public static Report inspect(File apkOrXapk) throws IOException {
        if (!apkOrXapk.isFile()) throw new IOException("Brak pliku pakietu");
        return inspectFiles(Collections.singletonList(apkOrXapk), new File(System.getProperty("java.io.tmpdir", ".")));
    }
    public static Report inspectFiles(List<File> paths) throws IOException {
        return inspectFiles(paths, new File(System.getProperty("java.io.tmpdir", ".")));
    }
    public static Report inspectFiles(List<File> paths, File scratchDir) throws IOException {
        Report report = new Report();
        for (File path : paths) {
            if (!path.isFile()) { report.notes.add("Pominięto niedostępny plik: " + path.getName()); continue; }
            try (ZipFile zip = new ZipFile(path)) { scanZip(zip, path.getName(), report, 0, scratchDir); }
        }
        if (report.archiveCount == 0) report.notes.add("Nie znaleziono wewnętrznego APK. Upewnij się, że to prawidłowy plik XAPK.");
        if (report.findings.size() >= MAX_FINDINGS) report.notes.add("Limit " + MAX_FINDINGS + " wskazówek; raport może być niepełny.");
        return report;
    }
    private static void scanZip(ZipFile zip, String location, Report report, int depth, File scratchDir) throws IOException {
        boolean apk = location.toLowerCase(Locale.ROOT).endsWith(".apk");
        if (apk) { report.archiveCount++; report.packageFiles.add(location); }
        Enumeration<? extends ZipEntry> items = zip.entries();
        while (items.hasMoreElements()) {
            ZipEntry entry = items.nextElement();
            if (entry.isDirectory()) continue;
            if (++report.entriesScanned > MAX_ENTRIES || report.scannedBytes > MAX_TOTAL_BYTES) {
                report.notes.add("Przerwano skanowanie po osiągnięciu limitu rozmiaru/liczby wpisów.");
                break;
            }
            String name = entry.getName();
            String path = location + "!" + name;
            if (name.contains("..") || name.startsWith("/")) continue; // no extraction, still reject suspicious paths
            for (String category : classify(name)) report.add(category, "Nazwa pliku", path, name);
            String lower = name.toLowerCase(Locale.ROOT);
            if (lower.endsWith(".apk") && depth == 0 && entry.getSize() >= 0 && entry.getSize() <= MAX_NESTED_APK) {
                File temp = File.createTempFile("nested-apk-", ".apk", scratchDir);
                try {
                    try (InputStream in=zip.getInputStream(entry); OutputStream out=new FileOutputStream(temp)) {
                        transferCapped(in, out, MAX_NESTED_APK);
                    }
                    try (ZipFile nested = new ZipFile(temp)) { scanZip(nested, path, report, depth+1, scratchDir); }
                } finally { if(!temp.delete()) temp.deleteOnExit(); }
                continue;
            }
            if (lower.matches("(^|.*/)classes([0-9]*)\\.dex") && entry.getSize() >= 0 && entry.getSize() <= MAX_DEX_ENTRY) {
                try (InputStream in = zip.getInputStream(entry)) {
                    byte[] data = readCapped(in, MAX_DEX_ENTRY);
                    report.scannedBytes += data.length;
                    report.dexCount++;
                    DexReader.read(data, path, report);
                } catch (RuntimeException e) { report.notes.add("Uszkodzona/nieobsługiwana tabela DEX: " + name); }
            } else if (isTextCandidate(lower) && entry.getSize() >= 0 && entry.getSize() <= MAX_TEXT_ENTRY) {
                try (InputStream in=zip.getInputStream(entry)) {
                    byte[] data = readCapped(in,MAX_TEXT_ENTRY);
                    report.scannedBytes += data.length;
                    scanText(data, path, report);
                }
            } else if (lower.startsWith("lib/") && lower.endsWith(".so")) {
                report.notes.add("Biblioteka natywna " + name + " wymaga osobnego analizatora (np. REA/Ghidra).");
            }
        }
    }
    private static boolean isTextCandidate(String name) {
        return name.endsWith(".txt") || name.endsWith(".json") || name.endsWith(".xml")
                || name.endsWith(".properties") || name.endsWith(".ini") || name.endsWith(".cfg")
                || name.endsWith(".js") || name.endsWith(".html") || name.endsWith(".csv")
                || name.endsWith(".yml") || name.endsWith(".yaml") || name.endsWith(".gradle");
    }
    private static void scanText(byte[] data, String path, Report report) {
        if (data.length == 0) return;
        int zero = 0; for (byte b : data) if (b == 0) zero++;
        if (zero > data.length / 100) return; // binary XML requires dedicated resource decoder
        String text = new String(data,StandardCharsets.UTF_8);
        String[] lines = text.split("[\\r\\n]",800);
        for (int i=0;i<lines.length;i++) {
            String line = lines[i].trim();
            if (line.length() > 260) line = line.substring(0,260);
            for (String category : classify(line)) {
                report.add(category,"Ciąg w zasobie",path+":"+(i+1),line);
            }
        }
    }
    private static byte[] readCapped(InputStream in, long limit) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        transferCapped(in,out,limit); return out.toByteArray();
    }
    private static void transferCapped(InputStream in, OutputStream out, long limit) throws IOException {
        byte[] buf = new byte[16*1024]; int n; long size=0;
        while ((n=in.read(buf))!=-1) {
            size+=n;
            if(size>limit) throw new IOException("Przekroczono limit rozmiaru archiwum");
            out.write(buf,0,n);
        }
    }
    private static final class DexReader {
        private static int int32(byte[] data,int at) {
            if (at<0 || at>data.length-4) throw new IllegalArgumentException("Nieprawidłowy offset DEX");
            return (data[at]&255)|((data[at+1]&255)<<8)|((data[at+2]&255)<<16)|((data[at+3]&255)<<24);
        }
        private static int uint16(byte[] data,int at) {
            if (at<0 || at>data.length-2) throw new IllegalArgumentException("Nieprawidłowy offset DEX");
            return (data[at]&255)|((data[at+1]&255)<<8);
        }
        private static void bounds(byte[] data,int off,int count,int width) {
            if (count < 0 || count > 150000 || off<0 || (long)off+(long)count*width>data.length)
                throw new IllegalArgumentException("Niewiarygodna tabela DEX");
        }
        static void read(byte[] bytes,String origin,Report report) {
            if(bytes.length<112 || bytes[0]!='d' || bytes[1]!='e' || bytes[2]!='x' || bytes[3]!='\n') {
                report.notes.add("Nie rozpoznano formatu DEX w " + origin); return;
            }
            int count=int32(bytes,0x38), stringOff=int32(bytes,0x3c);
            bounds(bytes,stringOff,count,4);
            String[] strings=new String[count];
            for(int i=0;i<count;i++) {
                int addr=int32(bytes,stringOff+i*4);
                strings[i]=decodeDexString(bytes,addr);
                if (strings[i].length() <= 160) for (String category : classify(strings[i])) {
                    report.add(category,"Ciąg DEX",origin+"#string["+i+"]",strings[i]);
                }
            }
            int typeCount=int32(bytes,0x40), typeOff=int32(bytes,0x44);
            bounds(bytes,typeOff,typeCount,4);
            int methodCount=int32(bytes,0x58), methodOff=int32(bytes,0x5c);
            bounds(bytes,methodOff,methodCount,8);
            report.methodCount += methodCount;
            int classDefsCount=int32(bytes,0x60), classDefsOff=int32(bytes,0x64);
            bounds(bytes,classDefsOff,classDefsCount,32);
            report.classCount += classDefsCount;
            HashSet<Integer> definedMethods = new HashSet<>();
            for (int i=0; i<classDefsCount; i++) {
                int item=classDefsOff+i*32;
                int idx=int32(bytes,item);
                if(idx>=0 && idx<typeCount) {
                    int classNameIndex=int32(bytes,typeOff+idx*4);
                    if(classNameIndex>=0 && classNameIndex<strings.length) {
                        String name=strings[classNameIndex].replace('/','.');
                        if (report.catalog.size()<Report.MAX_CATALOG) report.catalogAdd("Klasa zdefiniowana",name,origin+"#class["+i+"]");
                    }
                }
                int classDataOff=int32(bytes,item+24);
                if(classDataOff != 0) {
                    try { readClassData(bytes, classDataOff, methodCount, definedMethods); }
                    catch (IllegalArgumentException e) {
                        if(report.notes.size()<30) report.notes.add("Niepełna tablica class_data w "+origin+" (metody mogą być tylko referencjami)");
                    }
                }
            }
            for (int i=0;i<classDefsCount && report.packageNames.size()<80;i++) {
                int classTypeIndex=int32(bytes,classDefsOff+i*32);
                if(classTypeIndex<0 || classTypeIndex>=typeCount) continue;
                int classStringIdx=int32(bytes,typeOff+classTypeIndex*4);
                if(classStringIdx<0 || classStringIdx>=strings.length) continue;
                report.packageNames.add(strings[classStringIdx].replace('/','.'));
            }
            for(int i=0;i<methodCount;i++) {
                int at=methodOff + i*8;
                int typeIndex=uint16(bytes,at), nameIndex=int32(bytes,at+4);
                if(typeIndex>=typeCount || nameIndex<0 || nameIndex>=strings.length) continue;
                int classIndex=int32(bytes,typeOff+typeIndex*4);
                if(classIndex<0 || classIndex>=strings.length) continue;
                String symbol=strings[classIndex].replace('/','.')+"."+strings[nameIndex];
                if (report.methodSamples.size()<120 && symbol.length()<220) report.methodSamples.add(symbol);
                if (symbol.length()<400 && (report.catalog.size() < Report.MAX_CATALOG || !classify(symbol).isEmpty())) {
                    report.catalogAdd(definedMethods.contains(i)?"Metoda zdefiniowana":"Odwołanie do metody",symbol,origin+"#method["+i+"]");
                }
                for(String category: classify(symbol)) {
                    report.add(category,"Nazwa metody (bez dekompilacji)",origin+"#method["+i+"]",symbol);
                }
            }
        }
        private static int readUleb(byte[] data, int[] position) {
            int out=0;
            for (int i=0;i<5;i++) {
                if(position[0]>=data.length) throw new IllegalArgumentException("Błędny LEB128");
                int b=data[position[0]++]&255;
                out|=(b&127)<<(7*i);
                if((b&128)==0) return out;
            }
            throw new IllegalArgumentException("Zbyt długi LEB128");
        }
        private static void readClassData(byte[] data, int offset, int maxMethods, HashSet<Integer> defined) {
            if(offset<0 || offset>=data.length) throw new IllegalArgumentException("Błędny class_data_off");
            int[] p={offset};
            int staticFields=readUleb(data,p), instanceFields=readUleb(data,p);
            int directMethods=readUleb(data,p), virtualMethods=readUleb(data,p);
            if((long)staticFields+instanceFields>150000 || (long)directMethods+virtualMethods>maxMethods)
                throw new IllegalArgumentException("Za duża liczba pól lub metod");
            for(int i=0;i<staticFields+instanceFields;i++) { readUleb(data,p); readUleb(data,p); }
            for(int group=0;group<2;group++) {
                int count=(group==0?directMethods:virtualMethods), last=0;
                for(int i=0;i<count;i++) {
                    int delta=readUleb(data,p);
                    if(delta<0 || delta>maxMethods || last>maxMethods-delta) throw new IllegalArgumentException("Indeks metody poza zakresem");
                    last+=delta;
                    if(last>=maxMethods) throw new IllegalArgumentException("Indeks metody poza zakresem");
                    defined.add(last);
                    readUleb(data,p); // access flags
                    readUleb(data,p); // code offset
                }
            }
        }
        private static String decodeDexString(byte[] data,int pos) {
            if(pos<0 || pos>=data.length) throw new IllegalArgumentException("Błędny wskaźnik string");
            int count=0;
            while(pos<data.length && (data[pos++] & 0x80)!=0 && ++count<6) { }
            int end=pos;
            while(end<data.length && data[end]!=0 && end-pos<256) end++;
            if(end==data.length || end-pos>=256) return "";
            return new String(data,pos,end-pos,StandardCharsets.UTF_8);
        }
    }
}
