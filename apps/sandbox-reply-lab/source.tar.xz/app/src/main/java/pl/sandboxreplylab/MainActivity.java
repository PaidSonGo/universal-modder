package pl.sandboxreplylab;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.OpenableColumns;
import rikka.shizuku.Shizuku;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.*;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Visual local test harness for simulated entitlements in developer builds. */
public final class MainActivity extends Activity {
    private static final int PORT = 8765;
    private static final int DEBUG_PORT = 18768;
    private volatile LiveMemoryScanner debugScanner;
    private Runnable debugRefreshRunnable;
    private LiveMemoryBridge.Server debugServer;
    private TextView debugStatus;
    private EditText debugTokenInput, debugValueInput, debugEditInput;
    private Spinner debugType, debugFilter, debugHitPicker;
    private CheckBox debugUnknown;
    private volatile java.util.List<LiveMemoryScanner.Hit> debugShownHits = java.util.Collections.emptyList();
    private final java.util.concurrent.atomic.AtomicBoolean debugRefreshing = new java.util.concurrent.atomic.AtomicBoolean();
    private final LiveMemoryScanner.DemoTarget demoMemory = new LiveMemoryScanner.DemoTarget();
    private final LiveMemoryScanner memoryScanner = new LiveMemoryScanner(demoMemory);
    private final Handler memoryHandler = new Handler(Looper.getMainLooper());
    private Runnable memoryRefresh;
    private TextView memoryGameView, memoryStatusView, memoryResultsView;
    private EditText memoryValue, memoryEditValue;
    private Spinner memoryKind, memoryFilter, memoryHitPicker;
    private CheckBox memoryUnknown;
    private java.util.List<LiveMemoryScanner.Hit> shownMemoryHits = java.util.Collections.emptyList();
    private static final int PICK_ARCHIVE = 200;
    private static final int EXPORT_REPORT = 201;
    private static final int IMPORT_REA = 202;
    private static final int EXPORT_FLOW = 203;
    private static final int EXPORT_TERMUX = 204;
    private static final int SHIZUKU_PERMISSION = 410;
    private TextView scanStatus;
    private TextView resultView;
    private TextView shizukuStatus;
    private String latestReport = "";
    private ApkInspector.Report latestInspectorReport;
    private TextView catalogResultView;
    private EditText catalogSearchInput;
    private Spinner catalogCategorySelector;
    private EditText flowPackage, flowFrom, flowEvent, flowTo, flowNote;
    private TextView flowResultView;
    private FlowPlan activeFlow;
    private String pendingFlowExport = "";
    private File selectedArtifact;
    private File importedArtifact;
    private String selectedKind = "apk";
    private EditText reaTokenInput;
    private final Shizuku.OnBinderReceivedListener shizukuBinderListener = () -> runOnUiThread(this::refreshShizukuStatus);
    private final Shizuku.OnRequestPermissionResultListener shizukuResult = (code, grant) -> {
        if (code == SHIZUKU_PERMISSION) runOnUiThread(this::refreshShizukuStatus);
    };

    private final MockDecisionEngine engine = new MockDecisionEngine();
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private LocalMockServer server;
    private TextView status;
    private TextView logs;
    private TextView currentRule;
    private Button start;
    private Button stop;
    private int eventCount;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(23, 34, 48));
        getWindow().setNavigationBarColor(Color.rgb(23, 34, 48));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(26), dp(18), dp(24));
        root.setBackgroundColor(Color.rgb(245, 247, 251));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(root);
        setContentView(scroll);

        TextView heading = text("Sandbox Reply Lab", 26, Color.rgb(25, 42, 59), true);
        root.addView(heading);
        root.addView(text("Wersja 0.5.1 • pamięć debug + REA na telefonie", 12, Color.rgb(84,100,116), false));
        TextView explainer = text("Lokalny emulator odpowiedzi dla własnych aplikacji testowych. Nie realizuje płatności ani licencjonowania.", 14, Color.rgb(84, 100, 116), false);
        explainer.setPadding(0, dp(8), 0, dp(20));
        root.addView(explainer);

        LinearLayout panel = panel();
        root.addView(panel);
        panel.addView(text("SERWER TESTOWY", 12, Color.rgb(95, 110, 126), true));
        status = text("Wyłączony", 19, Color.rgb(172, 54, 44), true);
        status.setPadding(0, dp(7), 0, dp(7));
        panel.addView(status);
        panel.addView(text("127.0.0.1:8765/sandbox/purchase", 13, Color.rgb(54, 70, 84), false));
        LinearLayout controls = horizontal();
        controls.setPadding(0, dp(16), 0, 0);
        panel.addView(controls);
        start = button("Uruchom", Color.rgb(28, 91, 171));
        stop = button("Zatrzymaj", Color.rgb(72, 85, 100));
        controls.addView(start, weight());
        controls.addView(stop, weight());
        stop.setEnabled(false);

        LinearLayout rulesPanel = panel();
        root.addView(rulesPanel);
        rulesPanel.addView(text("REGUŁA ODPOWIEDZI", 12, Color.rgb(95, 110, 126), true));
        currentRule = text("Odmowa (domyślnie)", 19, Color.rgb(25, 42, 59), true);
        currentRule.setPadding(0, dp(7), 0, dp(5));
        rulesPanel.addView(currentRule);
        RadioGroup choices = new RadioGroup(this);
        choices.setOrientation(RadioGroup.VERTICAL);
        RadioButton deny = new RadioButton(this);
        deny.setText("Odrzuć żądanie (DECLINED)"); deny.setId(View.generateViewId());
        RadioButton approve = new RadioButton(this);
        approve.setText("Potwierdź TESTOWO (APPROVED)"); approve.setId(View.generateViewId());
        RadioButton error = new RadioButton(this);
        error.setText("Symuluj błąd (ERROR)"); error.setId(View.generateViewId());
        choices.addView(deny); choices.addView(approve); choices.addView(error);
        choices.check(deny.getId());
        rulesPanel.addView(choices);
        choices.setOnCheckedChangeListener((group, checked) -> {
            if (checked == approve.getId()) {
                engine.setMode(MockDecisionEngine.Mode.APPROVE);
                currentRule.setText("Testowe potwierdzenie");
            } else if (checked == error.getId()) {
                engine.setMode(MockDecisionEngine.Mode.ERROR);
                currentRule.setText("Symulacja błędu");
            } else {
                engine.setMode(MockDecisionEngine.Mode.DENY);
                currentRule.setText("Odmowa");
            }
        });
        Button demo = button("Wyślij próbne żądanie", Color.rgb(28, 91, 171));
        LinearLayout.LayoutParams demoParams = new LinearLayout.LayoutParams(-1, dp(50));
        demoParams.topMargin = dp(9);
        rulesPanel.addView(demo, demoParams);

        LinearLayout analyzePanel = panel();
        root.addView(analyzePanel);
        analyzePanel.addView(text("ANALIZATOR APLIKACJI — TYLKO ODCZYT", 12, Color.rgb(95, 110, 126), true));
        TextView instruction = text("Wybierz zainstalowaną aplikację lub otwórz APK/XAPK. Przeskanuję zasoby i symbole DEX pod kątem mechanizmów walut, reklam, zakupów, bonusów i zapisu.", 13, Color.rgb(54, 70, 84), false);
        instruction.setPadding(0, dp(10), 0, dp(12));
        analyzePanel.addView(instruction);
        LinearLayout selectRow = horizontal();
        analyzePanel.addView(selectRow);
        Button installedButton = button("Zainstalowane", Color.rgb(28, 91, 171));
        Button fileButton = button("APK / XAPK", Color.rgb(28, 91, 171));
        selectRow.addView(installedButton, weight());
        selectRow.addView(fileButton, weight());
        installedButton.setOnClickListener(v -> chooseInstalledPackage());
        fileButton.setOnClickListener(v -> chooseArchive());

        Button shizukuButton = button("Połącz z Shizuku", Color.rgb(72, 85, 100));
        LinearLayout.LayoutParams shy = new LinearLayout.LayoutParams(-1, dp(44));
        shy.topMargin = dp(8); analyzePanel.addView(shizukuButton, shy);
        shizukuStatus = text("Shizuku: sprawdzanie…", 13, Color.rgb(54, 70, 84), false);
        shizukuStatus.setPadding(0,dp(8),0,dp(6)); analyzePanel.addView(shizukuStatus);
        shizukuButton.setOnClickListener(v -> requestShizukuPermission());

        scanStatus = text("Brak wybranego pliku", 14, Color.rgb(84, 100, 116), false);
        scanStatus.setPadding(0, dp(10), 0, dp(9));
        analyzePanel.addView(scanStatus);
        resultView = text("Raport pojawi się tutaj. Wyniki to wskazówki, nie potwierdzenie miejsca przechowywania salda.", 12, Color.rgb(54, 70, 84), false);
        resultView.setTextIsSelectable(true);
        resultView.setPadding(0, dp(8), 0, dp(10));
        analyzePanel.addView(resultView);
        LinearLayout reportButtons = horizontal(); analyzePanel.addView(reportButtons);
        Button exportReport = button("Zapisz raport", Color.rgb(72, 85, 100));
        Button importRea = button("Wczytaj REA", Color.rgb(72, 85, 100));
        reportButtons.addView(exportReport, weight()); reportButtons.addView(importRea, weight());
        exportReport.setOnClickListener(v -> exportReport());
        importRea.setOnClickListener(v -> importRea());
        // Offline catalog is the default. REA host remains an optional advanced tool.
        TextView reaLabel = text("REA działa lokalnie w Termux na tym telefonie. Katalog DEX działa także bez REA. Wprowadź token serwera Termux, aby użyć analizy REA.", 12, Color.rgb(84,100,116), false);
        reaLabel.setPadding(0,dp(12),0,dp(6)); analyzePanel.addView(reaLabel);
        reaTokenInput = new EditText(this);
        reaTokenInput.setSingleLine(true);
        reaTokenInput.setHint("Token parowania REA (z terminala)");
        reaTokenInput.setTextSize(14);
        analyzePanel.addView(reaTokenInput);
        Button runRea = button("Analiza REA (komputer przez ADB)", Color.rgb(54,78,103));
        LinearLayout.LayoutParams reaParams = new LinearLayout.LayoutParams(-1,dp(48));
        reaParams.topMargin = dp(7); analyzePanel.addView(runRea,reaParams);
        runRea.setOnClickListener(v -> sendToRea(false));
        TextView onPhone = text("REA NA TYM TELEFONIE (TERMUX) — oryginalne REA uruchomione lokalnie w Termux, bez ADB i komputera. Wymaga osobnej konfiguracji Termux i Node.js. Analiza głęboka JADX może być niedostępna na Androidzie.", 12, Color.rgb(54,70,84), false);
        onPhone.setPadding(0, dp(12), 0, dp(6)); analyzePanel.addView(onPhone);
        Spinner mobileMode = new Spinner(this);
        mobileMode.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"inventory (REA, obsługiwany typ)", "deep (JADX, eksperymentalny)"}));
        analyzePanel.addView(mobileMode);
        Button mobileButton = button("REA lokalnie na telefonie", Color.rgb(28,91,171));
        analyzePanel.addView(mobileButton, fullButtonParams());
        mobileButton.setOnClickListener(v -> sendToRea(true, mobileMode.getSelectedItemPosition() == 1));
        Button testRea = button("Sprawdź połączenie REA / Termux", Color.rgb(72,85,100));
        analyzePanel.addView(testRea,fullButtonParams());
        testRea.setOnClickListener(v -> checkLocalRea());
        Button exportKit = button("Eksportuj instrukcję i most REA dla Termux", Color.rgb(72,85,100));
        analyzePanel.addView(exportKit,fullButtonParams());
        exportKit.setOnClickListener(v -> exportTermuxKit());
        Button openTermux = button("Otwórz Termux", Color.rgb(72,85,100));
        analyzePanel.addView(openTermux,fullButtonParams());
        openTermux.setOnClickListener(v -> {
            Intent intent=getPackageManager().getLaunchIntentForPackage("com.termux");
            if(intent==null) scanStatus.setText("Termux nie jest zainstalowany. Zainstaluj Termux z F-Droid lub GitHub Termux.");
            else startActivity(intent);
        });
        LinearLayout catalogPanel = panel();
        root.addView(catalogPanel);
        catalogPanel.addView(text("KATALOG OFFLINE — SZUKAJ KLAS I METOD", 12, Color.rgb(95, 110, 126), true));
        catalogPanel.addView(text("Wyszukiwanie pełnego indeksu odczytanych symboli DEX. 'Zdefiniowana' oznacza, że metoda należy do pakietu; 'odwołanie' może wskazywać na zewnętrzną bibliotekę.", 13, Color.rgb(54,70,84), false));
        catalogSearchInput = edit("np. Wallet, RewardedAd, SQLite, onClick");
        catalogPanel.addView(catalogSearchInput);
        String[] categories={"ALL", "KLASY", "METODY", "WALUTA", "REKLAMY", "PŁATNOŚCI", "BONUSY", "ZAPIS"};
        catalogCategorySelector = new Spinner(this);
        catalogCategorySelector.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, categories));
        catalogPanel.addView(catalogCategorySelector);
        Button catalogSearch = button("Szukaj lokalnie", Color.rgb(28,91,171));
        catalogPanel.addView(catalogSearch, fullButtonParams());
        catalogResultView = text("Najpierw przeanalizuj wybraną aplikację lub APK/XAPK.", 12, Color.rgb(54,70,84), false);
        catalogResultView.setTextIsSelectable(true);
        catalogPanel.addView(catalogResultView);
        catalogSearch.setOnClickListener(v -> searchCatalogOffline());

        addMemoryPanel(root);
        addDebugMemoryPanel(root);

        LinearLayout flowPanel = panel();
        root.addView(flowPanel);
        flowPanel.addView(text("PROJEKT ZMIANY PRZEPŁYWU — TYLKO WŁASNA APLIKACJA", 12, Color.rgb(95,110,126), true));
        flowPanel.addView(text("Zdefiniuj zmianę nawigacji między ekranami, zasymuluj ją i wyeksportuj JSON do własnego projektu źródłowego. NIE modyfikuje APK, nie omija licencji, płatności ani podpisów.", 13, Color.rgb(54,70,84), false));
        flowPackage = edit("Pakiet Twojej aplikacji, np. pl.example.demo");
        flowFrom = edit("Ekran startowy, np. MainScreen");
        flowEvent = edit("Zdarzenie, np. open_help");
        flowTo = edit("Ekran docelowy, np. HelpScreen");
        flowNote = edit("Opis testu / powód zmiany");
        flowPanel.addView(flowPackage); flowPanel.addView(flowFrom);
        flowPanel.addView(flowEvent); flowPanel.addView(flowTo); flowPanel.addView(flowNote);
        flowPackage.setText("pl.example.demo");
        flowFrom.setText("MainScreen"); flowEvent.setText("open_help"); flowTo.setText("HelpScreen");
        Button previewFlow = button("Zasymuluj zmianę", Color.rgb(28,91,171));
        Button exportFlow = button("Eksportuj JSON", Color.rgb(72,85,100));
        flowPanel.addView(previewFlow, fullButtonParams());
        flowPanel.addView(exportFlow, fullButtonParams());
        flowResultView = text("Scenariusz nie został jeszcze uruchomiony.", 12, Color.rgb(54,70,84), false);
        flowResultView.setTextIsSelectable(true);
        flowPanel.addView(flowResultView);
        previewFlow.setOnClickListener(v -> simulateDeveloperFlow());
        exportFlow.setOnClickListener(v -> exportDeveloperFlow());

        try {
            Shizuku.addRequestPermissionResultListener(shizukuResult);
            Shizuku.addBinderReceivedListenerSticky(shizukuBinderListener);
        } catch (Throwable ignored) { /* Shizuku service may not be installed */ }
        refreshShizukuStatus();

        LinearLayout logsPanel = panel();
        root.addView(logsPanel);
        logsPanel.addView(text("HISTORIA TESTÓW", 12, Color.rgb(95, 110, 126), true));
        logs = text("Brak żądań. Uruchom serwer, a następnie wyślij próbne żądanie.", 13, Color.rgb(54, 70, 84), false);
        logs.setPadding(0, dp(9), 0, 0);
        logsPanel.addView(logs);

        server = new LocalMockServer(engine, PORT, (path, productId, decision) -> runOnUiThread(() -> {
            eventCount++;
            String item = "#" + eventCount + "  " + productId + "  →  " + decision;
            String previous = eventCount == 1 ? "" : "\n" + logs.getText();
            String next = item + previous;
            logs.setText(next.length() > 3000 ? next.substring(0, 3000) : next);
        }));
        start.setOnClickListener(v -> startServer());
        stop.setOnClickListener(v -> stopServer());
        demo.setOnClickListener(v -> sendDemo());
    }

    private void addMemoryPanel(LinearLayout root) {
        LinearLayout card = panel(); root.addView(card);
        card.addView(text("LIVE MEMORY SCANNER — WŁASNY PROCES TESTOWY", 12, Color.rgb(95,110,126), true));
        card.addView(text("Działający skan prawdziwego bufora pamięci tej aplikacji (DirectByteBuffer). Adresy to przesunięcia w buforze, NIE pamięć innej gry. Dla własnych gier możesz zintegrować osobny adapter debug.", 13, Color.rgb(54,70,84), false));
        memoryGameView = text("Monety gry testowej: 1250", 19, Color.rgb(22,119,78), true);
        memoryGameView.setPadding(0,dp(10),0,dp(9)); card.addView(memoryGameView);
        LinearLayout earn = horizontal(); card.addView(earn);
        Button earnBtn = button("Monety +25", Color.rgb(28,91,171));
        Button spendBtn = button("Monety -30", Color.rgb(72,85,100));
        earn.addView(earnBtn,weight()); earn.addView(spendBtn,weight());
        earnBtn.setOnClickListener(v -> { demoMemory.earnCoins(25); updateMemoryLive(); });
        spendBtn.setOnClickListener(v -> { demoMemory.earnCoins(-30); updateMemoryLive(); });
        memoryKind = new Spinner(this);
        memoryKind.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"INT32", "INT64", "FLOAT", "DOUBLE", "INT16", "INT8"}));
        card.addView(memoryKind);
        memoryValue = edit("Wartość do wyszukania, np. 1250");
        memoryValue.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        memoryValue.setText("1250"); card.addView(memoryValue);
        memoryUnknown = new CheckBox(this); memoryUnknown.setText("Nieznana wartość początkowa");
        card.addView(memoryUnknown);
        Button startScan = button("Pierwszy skan", Color.rgb(28,91,171));
        card.addView(startScan,fullButtonParams());
        memoryFilter = new Spinner(this);
        memoryFilter.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"EXACT", "CHANGED", "UNCHANGED", "INCREASED", "DECREASED"}));
        card.addView(memoryFilter);
        Button nextScan = button("Następny skan (zawęż)", Color.rgb(54,78,103));
        card.addView(nextScan,fullButtonParams());
        memoryStatusView=text("Skan jeszcze nie uruchomiony",14,Color.rgb(54,70,84),false);
        card.addView(memoryStatusView);
        memoryResultsView=text("Brak wyników",12,Color.rgb(54,70,84),false);
        memoryResultsView.setTextIsSelectable(true); card.addView(memoryResultsView);
        memoryHitPicker = new Spinner(this);
        memoryHitPicker.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,new String[]{"Najpierw wyszukaj adres"}));
        card.addView(memoryHitPicker);
        memoryEditValue=edit("Nowa wartość do zapisania / zamrożenia");
        memoryEditValue.setText("9999"); card.addView(memoryEditValue);
        LinearLayout row = horizontal();card.addView(row);
        Button write = button("Zapisz",Color.rgb(28,91,171));
        Button freeze = button("Zamroź",Color.rgb(72,85,100));
        Button unfreeze = button("Odmroź",Color.rgb(72,85,100));
        row.addView(write,weight());row.addView(freeze,weight());row.addView(unfreeze,weight());
        startScan.setOnClickListener(v -> {
            try {
                int count=memoryUnknown.isChecked()
                        ?memoryScanner.beginUnknown(memorySelectedKind())
                        :memoryScanner.beginExact(memorySelectedKind(),memoryValue.getText().toString());
                memoryStatusView.setText("Pierwszy skan: "+count+" adresów"+(memoryScanner.isIncomplete()?" (limit wyników)":""));
                refreshMemoryResults();
            } catch(RuntimeException e) { memoryStatusView.setText("Błąd skanowania: "+e.getMessage()); }
        });
        nextScan.setOnClickListener(v -> {
            try {
                int count=memoryScanner.refine(LiveMemoryScanner.Filter.valueOf((String)memoryFilter.getSelectedItem()),memoryValue.getText().toString());
                memoryStatusView.setText("Pozostało "+count+" adresów");refreshMemoryResults();
            } catch(RuntimeException e) { memoryStatusView.setText("Błąd zawężania: "+e.getMessage()); }
        });
        write.setOnClickListener(v -> editDemoMemory("write"));
        freeze.setOnClickListener(v -> editDemoMemory("freeze"));
        unfreeze.setOnClickListener(v -> editDemoMemory("unfreeze"));
        memoryRefresh = new Runnable() {
            public void run() { updateMemoryLive(); memoryHandler.postDelayed(this,450); }
        };
        memoryHandler.postDelayed(memoryRefresh,450);
    }
    private LiveMemoryScanner.Kind memorySelectedKind() {
        return LiveMemoryScanner.Kind.valueOf((String)memoryKind.getSelectedItem());
    }
    private void refreshMemoryResults() {
        List<LiveMemoryScanner.Hit> all=memoryScanner.getResults();
        int maximum=Math.min(60,all.size());
        shownMemoryHits=new ArrayList<>(all.subList(0,maximum));
        String[] labels=new String[maximum==0?1:maximum];
        if(maximum==0) labels[0]="Brak pasujących adresów";
        for(int i=0;i<maximum;i++) {
            LiveMemoryScanner.Hit h=shownMemoryHits.get(i);
            labels[i]=String.format(java.util.Locale.ROOT,"0x%04X  =  %s",h.offset,h.value);
        }
        memoryHitPicker.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,labels));
        memoryResultsView.setText("Dostępne adresy: "+all.size()+". Lista pokazuje najwyżej 60; skaner działa tylko wewnątrz bufora testowego.");
    }
    private void editDemoMemory(String command) {
        if(shownMemoryHits.isEmpty()) {memoryStatusView.setText("Brak wybranego adresu");return;}
        int index=memoryHitPicker.getSelectedItemPosition();
        if(index<0 || index>=shownMemoryHits.size()) return;
        int offset=shownMemoryHits.get(index).offset;
        try {
            if(command.equals("freeze")) memoryScanner.freeze(offset,memoryEditValue.getText().toString());
            else if(command.equals("unfreeze")) memoryScanner.unfreeze(offset);
            else memoryScanner.edit(offset,memoryEditValue.getText().toString());
            memoryStatusView.setText(String.format(java.util.Locale.ROOT,"0x%04X: %s (%s)",offset,memoryScanner.readAt(offset),command));
            refreshMemoryResults();updateMemoryLive();
        } catch (RuntimeException e) {memoryStatusView.setText("Błąd zapisu: "+e.getMessage());}
    }
    private void updateMemoryLive() {
        if(memoryGameView==null) return;
        memoryScanner.applyFreezes();
        memoryGameView.setText("Monety gry testowej: "+demoMemory.coins());
        if(memoryHitPicker!=null && !shownMemoryHits.isEmpty()) {
            int index=memoryHitPicker.getSelectedItemPosition();
            if(index>=0 && index<shownMemoryHits.size()) {
                LiveMemoryScanner.Hit h=shownMemoryHits.get(index);
                String prefix=String.format(java.util.Locale.ROOT,"0x%04X",h.offset);
                memoryResultsView.setText("Na żywo: "+prefix+" = "+memoryScanner.readAt(h.offset)
                     +(memoryScanner.isFrozen(h.offset)?" [FROZEN]":"")
                     +"\nKandydaci: "+memoryScanner.count()+"; lista: pierwsze "+shownMemoryHits.size());
            }
        }
    }

    /** Full value search across processes is opt-in: the target app must embed LiveMemoryBridge.Server. */
    private void addDebugMemoryPanel(LinearLayout root) {
        LinearLayout panel = panel(); root.addView(panel);
        panel.addView(text("LIVE MEMORY — WŁASNA GRA Z INTERFEJSEM DEBUG",12,Color.rgb(95,110,126),true));
        panel.addView(text("Zdalny odczyt i edycja rzeczywistych wartości w innym procesie na tym telefonie. Wymaga dodania LiveMemoryBridge.Server do WŁASNEGO buildu debug; bez roota, bez Shizuku, bez dostępu do obcych gier.",13,Color.rgb(54,70,84),false));
        debugTokenInput=edit("Token z aplikacji debugowanej (min. 12 znaków)");
        panel.addView(debugTokenInput);
        Button serve=button("Uruchom testowy serwer tego procesu",Color.rgb(72,85,100));
        panel.addView(serve,fullButtonParams());
        Button attach=button("Połącz z grą debug na localhost:18768",Color.rgb(28,91,171));
        panel.addView(attach,fullButtonParams());
        debugStatus=text("Brak połączenia",13,Color.rgb(54,70,84),false);
        debugStatus.setTextIsSelectable(true);panel.addView(debugStatus);
        debugType=new Spinner(this);
        debugType.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,
                new String[]{"INT32","INT64","FLOAT","DOUBLE","INT16","INT8"}));
        panel.addView(debugType);
        debugValueInput=edit("Wartość poszukiwana / dokładna");
        debugValueInput.setText("1250");panel.addView(debugValueInput);
        debugUnknown=new CheckBox(this);debugUnknown.setText("Nieznana wartość początkowa");panel.addView(debugUnknown);
        Button first=button("Pierwszy skan procesu debug",Color.rgb(28,91,171));panel.addView(first,fullButtonParams());
        debugFilter=new Spinner(this);
        debugFilter.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,
                new String[]{"EXACT","CHANGED","UNCHANGED","INCREASED","DECREASED"}));
        panel.addView(debugFilter);
        Button narrow=button("Następny skan",Color.rgb(54,78,103));panel.addView(narrow,fullButtonParams());
        debugHitPicker=new Spinner(this);
        debugHitPicker.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Brak skanu"}));panel.addView(debugHitPicker);
        debugEditInput=edit("Wpisz nową wartość dla wybranego adresu");
        debugEditInput.setText("9999");panel.addView(debugEditInput);
        LinearLayout operations=horizontal();panel.addView(operations);
        Button write=button("Zapisz",Color.rgb(28,91,171));
        Button freeze=button("Zamroź",Color.rgb(72,85,100));
        Button unfreeze=button("Odmroź",Color.rgb(72,85,100));
        operations.addView(write,weight());operations.addView(freeze,weight());operations.addView(unfreeze,weight());
        serve.setEnabled(BuildConfig.DEBUG);
        if (!BuildConfig.DEBUG) panel.addView(text("Serwer pamięci jest wyłączony w wydaniu produkcyjnym. Włącz go tylko we własnej kompilacji debug aplikacji docelowej.",12,Color.rgb(84,100,116),false));
        serve.setOnClickListener(v -> {
            if (!BuildConfig.DEBUG) {debugStatus.setText("Serwer jest dostępny wyłącznie w buildzie debug");return;}
            try {
                if(debugServer!=null) debugServer.close();
                String newToken=java.util.UUID.randomUUID().toString();
                debugServer=new LiveMemoryBridge.Server(demoMemory,DEBUG_PORT,newToken);
                debugServer.start();debugTokenInput.setText(newToken);
                debugStatus.setText("TESTOWY SERWER NA TYM TELEFONIE uruchomiony. Token wpisany powyżej. Możesz nacisnąć Połącz.");
            } catch(Exception e) { debugStatus.setText("Nie można uruchomić serwera: "+e.getMessage()); }
        });
        attach.setOnClickListener(v -> {
            final String token=debugTokenInput.getText().toString().trim();
            debugStatus.setText("Sprawdzam lokalne połączenie…");
            worker.execute(() -> {
                try {
                    LiveMemoryBridge.Client connected=new LiveMemoryBridge.Client("127.0.0.1",DEBUG_PORT,token);
                    int bytes=connected.snapshot().length;
                    debugScanner=new LiveMemoryScanner(connected);
                    runOnUiThread(() -> debugStatus.setText("Połączono: "+bytes+" bajtów pamięci wystawionych przez program debug. Możesz skanować."));
                } catch(Exception e) { debugScanner=null; runOnUiThread(() -> debugStatus.setText("Błąd połączenia: "+e.getMessage())); }
            });
        });
        first.setOnClickListener(v -> {
            LiveMemoryScanner scan=debugScanner;
            if(scan==null) {debugStatus.setText("Najpierw połącz grę debug");return;}
            LiveMemoryScanner.Kind kind=LiveMemoryScanner.Kind.valueOf((String)debugType.getSelectedItem());
            boolean unknown=debugUnknown.isChecked();String search=debugValueInput.getText().toString();
            debugStatus.setText("Skanuję…");
            worker.execute(() -> {
                try {
                    int total=unknown?scan.beginUnknown(kind):scan.beginExact(kind,search);
                    java.util.List<LiveMemoryScanner.Hit> hits=scan.getResults();
                    runOnUiThread(() -> showDebugResults("Pierwszy skan: "+total+" adresów",hits));
                } catch(Exception e) {runOnUiThread(() -> debugStatus.setText("Błąd skanowania: "+e.getMessage()));}
            });
        });
        narrow.setOnClickListener(v -> {
            LiveMemoryScanner scan=debugScanner;
            if(scan==null) {debugStatus.setText("Najpierw połącz grę debug");return;}
            LiveMemoryScanner.Filter filter=LiveMemoryScanner.Filter.valueOf((String)debugFilter.getSelectedItem());
            String search=debugValueInput.getText().toString();
            debugStatus.setText("Zawężam…");
            worker.execute(() -> {
                try {
                    int total=scan.refine(filter,search);
                    java.util.List<LiveMemoryScanner.Hit> hits=scan.getResults();
                    runOnUiThread(() -> showDebugResults("Zawężanie: "+total+" adresów",hits));
                } catch(Exception e) {runOnUiThread(() -> debugStatus.setText("Błąd: "+e.getMessage()));}
            });
        });
        write.setOnClickListener(v -> modifyDebugMemory("write"));
        freeze.setOnClickListener(v -> modifyDebugMemory("freeze"));
        unfreeze.setOnClickListener(v -> modifyDebugMemory("unfreeze"));
        debugRefreshRunnable = new Runnable() {
            @Override public void run() {
                LiveMemoryScanner scan=debugScanner;
                if(scan!=null && scan.count()>0 && debugRefreshing.compareAndSet(false,true)) {
                    worker.execute(() -> {
                        try {
                            scan.applyFreezes();
                            java.util.List<LiveMemoryScanner.Hit> hits=scan.getResults();
                            runOnUiThread(() -> {
                                // Do not reset the selected offset during periodic refresh.
                                int pos=debugHitPicker.getSelectedItemPosition();
                                if(pos>=0 && pos<hits.size() && pos<debugShownHits.size()) {
                                    LiveMemoryScanner.Hit hit=hits.get(pos);
                                    debugStatus.setText("Na żywo: 0x"+Integer.toHexString(hit.offset).toUpperCase(java.util.Locale.ROOT)
                                           +" = "+hit.value+(scan.isFrozen(hit.offset)?" [ZAMROŻONE]":"")
                                           +" • kandydaci: "+scan.count());
                                }
                            });
                        } catch(Exception e) {runOnUiThread(() -> debugStatus.setText("Utracono połączenie debug: "+e.getMessage()));}
                        finally {debugRefreshing.set(false);}
                    });
                }
                if(!isFinishing() && !isDestroyed()) memoryHandler.postDelayed(this,650);
            }
        };
        memoryHandler.postDelayed(debugRefreshRunnable,650);
    }
    private void showDebugResults(String message, java.util.List<LiveMemoryScanner.Hit> hits) {
        int limit=Math.min(70,hits.size());
        debugShownHits=new ArrayList<>(hits.subList(0,limit));
        String[] names=new String[limit==0?1:limit];
        if(limit==0) names[0]="Brak pasujących adresów";
        for(int i=0;i<limit;i++) {
            LiveMemoryScanner.Hit h=hits.get(i);
            names[i]=String.format(java.util.Locale.ROOT,"0x%04X = %s",h.offset,h.value);
        }
        debugHitPicker.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));
        debugStatus.setText(message+". Pokazuję "+limit+" pierwszych wyników.");
    }
    private void modifyDebugMemory(String action) {
        LiveMemoryScanner scan=debugScanner;
        int pos=debugHitPicker.getSelectedItemPosition();
        java.util.List<LiveMemoryScanner.Hit> hits=debugShownHits;
        if(scan==null || pos<0 || pos>=hits.size()) {debugStatus.setText("Wybierz znaleziony adres");return;}
        int offset=hits.get(pos).offset;
        String value=debugEditInput.getText().toString();
        worker.execute(() -> {
            try {
                if("freeze".equals(action)) scan.freeze(offset,value);
                else if("unfreeze".equals(action)) scan.unfreeze(offset);
                else scan.edit(offset,value);
                String result=scan.readAt(offset);
                runOnUiThread(() -> debugStatus.setText("Zapisano: 0x"+Integer.toHexString(offset)+" = "+result+" • "+action));
            } catch(Exception e) {runOnUiThread(() -> debugStatus.setText("Błąd edycji: "+e.getMessage()));}
        });
    }

    private void chooseArchive() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, PICK_ARCHIVE);
    }

    private void chooseInstalledPackage() {
        try {
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> apps = pm.getInstalledApplications(0);
            apps.sort(Comparator.comparing(a -> a.loadLabel(pm).toString().toLowerCase(java.util.Locale.ROOT)));
            String[] choices = new String[apps.size()];
            for (int i=0;i<apps.size();i++) {
                ApplicationInfo a=apps.get(i);
                choices[i] = a.loadLabel(pm) + "  (" + a.packageName + ")";
            }
            new android.app.AlertDialog.Builder(this)
                    .setTitle("Wybierz aplikację do analizy")
                    .setItems(choices,(dialog,which) -> scanInstalled(apps.get(which)))
                    .setNegativeButton("Anuluj",null).show();
        } catch (Exception e) { scanStatus.setText("Nie można uzyskać listy aplikacji: " + e.getMessage()); }
    }

    private void scanInstalled(ApplicationInfo app) {
        ArrayList<File> paths = new ArrayList<>();
        if (app.sourceDir != null) paths.add(new File(app.sourceDir));
        if (app.splitSourceDirs != null) for (String path : app.splitSourceDirs) paths.add(new File(path));
        selectedArtifact = paths.isEmpty() ? null : paths.get(0);
        selectedKind = "apk";
        scanStatus.setText("Analizuję " + app.packageName + "…");
        flowPackage.setText(app.packageName);
        runScan(paths, app.packageName);
    }

    private void runScan(List<File> files, String title) {
        worker.execute(() -> {
            try {
                ApkInspector.Report result = ApkInspector.inspectFiles(files, getCacheDir());
                String report = "Cel: " + title + "\n" + result.toText();
                runOnUiThread(() -> {
                    latestReport = report;
                    latestInspectorReport = result;
                    catalogResultView.setText("Indeks gotowy: "+result.catalog.size()+" symboli. Wyszukaj klasę lub metodę.");
                    scanStatus.setText("Skan ukończony: " + result.findings.size() + " wskazówek (maks. 220)");
                    // Keep UI responsive for enormous package inventories; full report is exportable.
                    resultView.setText(report.length() > 23000 ? report.substring(0,23000)+"\n[Podgląd skrócony — zapisz cały raport.]" : report);
                });
            } catch (Exception e) {
                runOnUiThread(() -> scanStatus.setText("Błąd analizy: " + e.getMessage()));
            }
        });
    }
    private EditText edit(String placeholder) {
        EditText field = new EditText(this);
        field.setSingleLine(true);
        field.setTextSize(14);
        field.setHint(placeholder);
        return field;
    }
    private LinearLayout.LayoutParams fullButtonParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(46));
        params.topMargin=dp(8);
        params.bottomMargin=dp(5);
        return params;
    }
    private void searchCatalogOffline() {
        if(latestInspectorReport==null) {
            catalogResultView.setText("Najpierw wykonaj analizę APK/XAPK."); return;
        }
        String query=catalogSearchInput.getText().toString();
        String scope=(String)catalogCategorySelector.getSelectedItem();
        List<ApkInspector.CatalogSymbol> symbols=latestInspectorReport.searchCatalog(query,scope,150);
        StringBuilder output=new StringBuilder("Wyniki: "+symbols.size()+" (maks. 150 na ekranie)\n");
        for(ApkInspector.CatalogSymbol item:symbols) {
            if(output.length()>32000) { output.append("\n[Widok ograniczony do 32 000 znaków]"); break; }
            output.append("\n").append(item.kind).append(" • ").append(item.name)
                  .append("\n").append(item.location).append("\n");
        }
        if(symbols.isEmpty()) output.append("\nBrak dopasowań w zindeksowanych symbolach. ");
        catalogResultView.setText(output.toString());
    }
    private FlowPlan compileDeveloperFlow() {
        return FlowPlan.create(flowPackage.getText().toString(), flowFrom.getText().toString(),
                flowEvent.getText().toString(), flowTo.getText().toString(), flowNote.getText().toString());
    }
    private void simulateDeveloperFlow() {
        try {
            activeFlow=compileDeveloperFlow();
            String target=activeFlow.simulate(activeFlow.fromScreen,activeFlow.eventName,"DomyślnyEkran");
            flowResultView.setText("SYMULACJA OFFLINE — ukończona\nZdarzenie: "+activeFlow.eventName
                +"\nEkran: "+activeFlow.fromScreen+" → "+target
                +"\nBrak zmian w oryginalnym APK. Aby wdrożyć zmianę, aplikacja źródłowa musi odczytywać tę konfigurację.");
        } catch(IllegalArgumentException e) { flowResultView.setText("Błąd scenariusza: "+e.getMessage()); }
    }
    private void exportDeveloperFlow() {
        try {
            activeFlow=compileDeveloperFlow();
            pendingFlowExport=activeFlow.toJson();
            Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.setType("application/json");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.putExtra(Intent.EXTRA_TITLE,"developer-flow-plan.json");
            startActivityForResult(intent,EXPORT_FLOW);
        } catch(IllegalArgumentException e) { flowResultView.setText("Błąd scenariusza: "+e.getMessage()); }
    }

    private void requestShizukuPermission() {
        try {
            if (!Shizuku.pingBinder()) {
                shizukuStatus.setText("Brak aktywnego serwera Shizuku. Uruchom Shizuku w jego aplikacji.");
                return;
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                refreshShizukuStatus(); return;
            }
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                shizukuStatus.setText("Odmówiono uprawnienia w Shizuku. Zmień je w menedżerze Shizuku."); return;
            }
            Shizuku.requestPermission(SHIZUKU_PERMISSION);
        } catch (Throwable e) { shizukuStatus.setText("Shizuku niedostępne: " + e.getClass().getSimpleName()); }
    }
    private void refreshShizukuStatus() {
        if (shizukuStatus == null) return;
        try {
            if (!Shizuku.pingBinder()) { shizukuStatus.setText("Shizuku: nieaktywny serwer (opcjonalne)"); return; }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                shizukuStatus.setText("Shizuku: połączono, przyznano zgodę. Bez odczytu danych prywatnych.");
            } else shizukuStatus.setText("Shizuku: aktywny, wymaga zgody użytkownika");
        } catch(Throwable e) { shizukuStatus.setText("Shizuku: niedostępne (analizator działa bez niego)"); }
    }
    private void sendToRea(boolean mobile) { sendToRea(mobile,false); }
    private void sendToRea(boolean mobile, boolean deep) {
        final File artifact = selectedArtifact;
        final String kind = selectedKind;
        final String token = reaTokenInput.getText().toString().trim();
        if (artifact == null || !artifact.isFile()) {
            Toast.makeText(this,"Najpierw wybierz APK lub aplikację",Toast.LENGTH_LONG).show(); return;
        }
        if (token.isEmpty()) {
            Toast.makeText(this,"Wpisz token z uruchomionego REA bridge",Toast.LENGTH_LONG).show(); return;
        }
        new android.app.AlertDialog.Builder(this)
            .setTitle(mobile ? "REA w Termux (ten telefon)" : "REA na komputerze")
            .setMessage(mobile ? "Przekazać APK przez localhost do REA uruchomionego w Termux na TYM telefonie? Oryginalny silnik analizuje tylko plik, nie uruchamia gry. Tryb głęboki wymaga JVM/JADX." : "Przesłać APK do procesu REA na Twoim komputerze przez ADB reverse? Wybieraj wyłącznie pliki, do których analizy masz uprawnienia.")
            .setNegativeButton("Anuluj",null)
            .setPositiveButton("Prześlij lokalnie",(dialog,which) -> {
                scanStatus.setText(mobile ? "REA: lokalna analiza w Termux…" : "REA: przesyłam przez ADB reverse…");
                worker.execute(() -> {
                    HttpURLConnection c=null;
                    try {
                        if (artifact.length()>(mobile?180L:200L)*1024*1024) throw new IOException("REA bridge: limit rozmiaru pliku");
                        c=(HttpURLConnection)new URL(mobile ? "http://127.0.0.1:18767/analyze" : "http://127.0.0.1:18766/analyze").openConnection();
                        c.setRequestMethod("POST");
                        c.setConnectTimeout(5000);
                        c.setReadTimeout(480000);
                        c.setRequestProperty("X-Sandbox-Token",token);
                        c.setRequestProperty("X-Package-Type",kind);
                        if (mobile) c.setRequestProperty("X-Rea-Mode",deep?"deep":"inventory");
                        c.setRequestProperty("Content-Type","application/octet-stream");
                        c.setDoOutput(true);
                        c.setFixedLengthStreamingMode(artifact.length());
                        try(InputStream in=new FileInputStream(artifact);OutputStream out=c.getOutputStream()) {
                            byte[] buffer=new byte[64*1024]; int n;
                            while((n=in.read(buffer))!=-1) out.write(buffer,0,n);
                        }
                        int statusCode=c.getResponseCode();
                        InputStream reply=statusCode<400?c.getInputStream():c.getErrorStream();
                        ByteArrayOutputStream response=new ByteArrayOutputStream();
                        try(InputStream in=reply) {
                            byte[] buffer=new byte[4096]; int n;
                            while((n=in.read(buffer))!=-1) {
                                if(response.size()+n>6*1024*1024) throw new IOException("Odpowiedź REA za duża");
                                response.write(buffer,0,n);
                            }
                        }
                        final String output=(mobile?"REA Termux ":"REA host ")+"HTTP "+statusCode+"\n"+response.toString("UTF-8");
                        runOnUiThread(() -> {
                            latestReport=output;
                            resultView.setText(output.length()>23000?output.substring(0,23000)+"\n[Podgląd skrócony — zapisz cały raport.]":output);
                            scanStatus.setText(statusCode==200?"REA: otrzymano wyniki":"REA: host zgłosił błąd HTTP "+statusCode);
                        });
                    } catch(Exception e) {
                        runOnUiThread(() -> scanStatus.setText("REA: "+e.getMessage()+(mobile?". Uruchom most w Termux, sprawdź token.":". Sprawdź adb reverse i token.")));
                    } finally { if(c!=null) c.disconnect(); }
                });
            }).show();
    }

    private void exportTermuxKit() {
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_TITLE,"srl-termux-kit.zip");
        startActivityForResult(intent,EXPORT_TERMUX);
    }
    private void checkLocalRea() {
        final String token=reaTokenInput.getText().toString().trim();
        if(token.isEmpty()) {scanStatus.setText("Wpisz token wyświetlony w Termux przez serwer REA.");return;}
        worker.execute(() -> {
            HttpURLConnection conn=null;
            try {
                conn=(HttpURLConnection)new URL("http://127.0.0.1:18767/health").openConnection();
                conn.setRequestProperty("X-Sandbox-Token",token);
                conn.setConnectTimeout(2500);conn.setReadTimeout(3500);
                int statusCode=conn.getResponseCode();
                String answer="REA Termux: HTTP "+statusCode;
                if(statusCode==200) {
                    try(InputStream in=conn.getInputStream()) {
                        ByteArrayOutputStream result=new ByteArrayOutputStream();
                        byte[] b=new byte[1024];int n;
                        while((n=in.read(b))!=-1 && result.size()<5000) result.write(b,0,n);
                        answer+=" "+result.toString("UTF-8");
                    }
                }
                final String msg=answer;
                runOnUiThread(() -> scanStatus.setText(msg));
            } catch(Exception e) {
                runOnUiThread(() -> scanStatus.setText("REA na telefonie niedostępne: "+e.getMessage()));
            } finally {if(conn!=null) conn.disconnect();}
        });
    }

    private void exportReport() {
        if (latestReport.isEmpty()) { Toast.makeText(this,"Najpierw przeanalizuj APK",Toast.LENGTH_SHORT).show(); return; }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.setType("text/plain"); intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_TITLE,"sandbox-reply-lab-report.txt");
        startActivityForResult(intent, EXPORT_REPORT);
    }
    private void importRea() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("*/*"); intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, IMPORT_REA);
    }
    @Override protected void onActivityResult(int code, int resultCode, Intent data) {
        super.onActivityResult(code,resultCode,data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (code == EXPORT_TERMUX) {
            worker.execute(() -> {
                try(InputStream in=getAssets().open("rea-termux-kit.zip");
                    OutputStream out=getContentResolver().openOutputStream(uri)) {
                    if(out==null) throw new IOException("Brak dostępu do lokalizacji zapisu");
                    byte[] buffer=new byte[65536];int n;
                    while((n=in.read(buffer))!=-1) out.write(buffer,0,n);
                    runOnUiThread(() -> scanStatus.setText("Zapisano pakiet REA dla Termux. Rozpakuj go w Download."));
                } catch(Exception e) {
                    runOnUiThread(() -> scanStatus.setText("Nie udało się zapisać pakietu REA: "+e.getMessage()));
                }
            });
        } else if (code == EXPORT_FLOW) {
            String json = pendingFlowExport;
            worker.execute(() -> {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IOException("Brak strumienia do zapisu JSON");
                    out.write(json.getBytes(StandardCharsets.UTF_8));
                    runOnUiThread(() -> flowResultView.setText("Zapisano projekt nawigacji. To konfiguracja do własnego kodu, nie przebudowany i podpisany APK."));
                } catch(Exception e) { runOnUiThread(() -> flowResultView.setText("Błąd eksportu: "+e.getMessage())); }
            });
        } else if (code == EXPORT_REPORT) {
            String text = latestReport;
            worker.execute(() -> {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IOException("Nie można zapisać pliku");
                    out.write(text.getBytes(StandardCharsets.UTF_8));
                    runOnUiThread(() -> Toast.makeText(this,"Raport zapisany",Toast.LENGTH_LONG).show());
                } catch(Exception e) { runOnUiThread(() -> scanStatus.setText("Błąd zapisu: "+e.getMessage())); }
            });
        } else if (code == PICK_ARCHIVE) {
            String display = displayName(uri);
            String suffix = display.toLowerCase(java.util.Locale.ROOT).endsWith(".xapk") ? ".xapk" : ".apk";
            scanStatus.setText("Importuję " + display + "…");
            worker.execute(() -> {
                File temp = null;
                try {
                    temp=File.createTempFile("sandbox-import-",suffix,getCacheDir());
                    try(InputStream in=getContentResolver().openInputStream(uri); OutputStream out=new FileOutputStream(temp)) {
                        if(in==null) throw new IOException("Brak dostępu do pliku");
                        byte[] buf=new byte[64*1024]; long size=0; int n;
                        while((n=in.read(buf))!=-1) {
                            size+=n; if(size>300L*1024*1024) throw new IOException("Limit importu 300 MB");
                            out.write(buf,0,n);
                        }
                    }
                    final File input=temp;
                    ApkInspector.Report result=ApkInspector.inspectFiles(java.util.Collections.singletonList(input), getCacheDir());
                    String report="Plik: "+display+"\n"+result.toText();
                    runOnUiThread(() -> {
                        if (importedArtifact!=null && importedArtifact!=input && importedArtifact.exists()) importedArtifact.delete();
                        importedArtifact=input;
                        selectedArtifact=input;
                        selectedKind=suffix.substring(1);
                        latestReport=report;
                        latestInspectorReport=result;
                        catalogResultView.setText("Indeks gotowy: "+result.catalog.size()+" symboli. Wyszukaj klasę lub metodę.");
                        scanStatus.setText("Skan ukończony: "+result.findings.size()+" wskazówek");
                        resultView.setText(report.length()>23000?report.substring(0,23000)+"\n[Podgląd skrócony — zapisz cały raport.]":report);
                    });
                } catch(Exception e) {
                    if (temp!=null) temp.delete();
                    runOnUiThread(() -> scanStatus.setText("Błąd importu/analizy: "+e.getMessage()));
                }
            });
        } else if (code == IMPORT_REA) {
            worker.execute(() -> {
                try(InputStream in=getContentResolver().openInputStream(uri)) {
                    if(in==null) throw new IOException("Nie można otworzyć raportu");
                    ByteArrayOutputStream buffer=new ByteArrayOutputStream();
                    byte[] bytes=new byte[4096]; int count;
                    while((count=in.read(bytes))!=-1) {
                        if(buffer.size()+count>2*1024*1024) throw new IOException("Raport przekracza 2 MB");
                        buffer.write(bytes,0,count);
                    }
                    String report="Raport REA (import z hosta, bez własnej weryfikacji):\n"+buffer.toString("UTF-8");
                    runOnUiThread(() -> { latestReport=report; scanStatus.setText("Wczytano raport zewnętrzny");
                        resultView.setText(report.length()>23000?report.substring(0,23000)+"\n[Podgląd skrócony — zapisz cały raport.]":report); });
                } catch(Exception e) { runOnUiThread(() -> scanStatus.setText("Błąd raportu REA: "+e.getMessage())); }
            });
        }
    }
    private String displayName(Uri uri) {
        String name="wybrany.apk";
        try (android.database.Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)) {
            if(c!=null && c.moveToFirst()) name=c.getString(0);
        } catch(Exception ignored) { }
        return name==null?"wybrany.apk":name;
    }

    private void startServer() {
        try {
            server.start();
            status.setText("Aktywny — tylko lokalnie");
            status.setTextColor(Color.rgb(22, 119, 78));
            start.setEnabled(false);
            stop.setEnabled(true);
        } catch (IOException e) {
            status.setText("Błąd uruchomienia: " + e.getMessage());
        }
    }

    private void stopServer() {
        server.stop();
        status.setText("Wyłączony");
        status.setTextColor(Color.rgb(172, 54, 44));
        start.setEnabled(true);
        stop.setEnabled(false);
    }

    private void sendDemo() {
        if (!server.isRunning()) {
            Toast.makeText(this, "Najpierw uruchom serwer", Toast.LENGTH_SHORT).show();
            return;
        }
        worker.execute(() -> {
            String output;
            HttpURLConnection conn = null;
            try {
                URL url = new URL("http://127.0.0.1:" + PORT + "/sandbox/purchase");
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(2500);
                conn.setReadTimeout(2500);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);
                byte[] body = "{\"productId\":\"demo_premium\"}".getBytes(StandardCharsets.UTF_8);
                conn.setFixedLengthStreamingMode(body.length);
                try (OutputStream stream = conn.getOutputStream()) { stream.write(body); }
                try (InputStream stream = conn.getInputStream()) {
                    ByteArrayOutputStream data = new ByteArrayOutputStream();
                    byte[] buffer = new byte[512]; int count;
                    while ((count = stream.read(buffer)) != -1) data.write(buffer, 0, count);
                    output = data.toString("UTF-8");
                }
            } catch (Exception e) {
                output = "Błąd żądania: " + e.getMessage();
            } finally {
                if (conn != null) conn.disconnect();
            }
            final String result = output;
            runOnUiThread(() -> new android.app.AlertDialog.Builder(this)
                    .setTitle("Odpowiedź emulatora")
                    .setMessage(result)
                    .setPositiveButton("OK", null)
                    .show());
        });
    }

    @Override protected void onDestroy() {
        if (server != null) server.stop();
        if (debugServer != null) try { debugServer.close(); } catch(IOException ignored) { }
        try { Shizuku.removeRequestPermissionResultListener(shizukuResult); } catch(Throwable ignored) { }
        try { Shizuku.removeBinderReceivedListener(shizukuBinderListener); } catch(Throwable ignored) { }
        if(memoryRefresh!=null) memoryHandler.removeCallbacks(memoryRefresh);
        if(debugRefreshRunnable!=null) memoryHandler.removeCallbacks(debugRefreshRunnable);
        worker.shutdownNow();
        if(importedArtifact!=null) importedArtifact.delete();
        super.onDestroy();
    }

    private LinearLayout panel() {
        LinearLayout pane = new LinearLayout(this);
        pane.setOrientation(LinearLayout.VERTICAL);
        pane.setPadding(dp(17), dp(18), dp(17), dp(18));
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(Color.WHITE);
        shape.setCornerRadius(dp(15));
        shape.setStroke(dp(1), Color.rgb(225, 231, 239));
        pane.setBackground(shape);
        LinearLayout.LayoutParams margins = new LinearLayout.LayoutParams(-1, -2);
        margins.bottomMargin = dp(15);
        pane.setLayoutParams(margins);
        return pane;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(null, Typeface.BOLD);
        return view;
    }
    private Button button(String label, int color) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setTextColor(Color.WHITE);
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(8));
        btn.setBackground(shape);
        return btn;
    }
    private LinearLayout horizontal() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        return layout;
    }
    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(45), 1f);
        params.setMargins(dp(3), 0, dp(3), 0);
        return params;
    }
    private int dp(int number) { return (int)(number * getResources().getDisplayMetrics().density + 0.5f); }
}
