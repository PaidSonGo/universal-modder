package pl.sandboxreplylab;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * In-process memory scanner for a developer-owned sandbox buffer. Addresses are
 * buffer offsets, NOT addresses in a separate app/process. Does not use ptrace,
 * root, Shizuku, injection or process memory access.
 */
public final class LiveMemoryScanner {
    public enum Kind {
        INT8(1), INT16(2), INT32(4), INT64(8), FLOAT(4), DOUBLE(8);
        public final int bytes;
        Kind(int n) { bytes = n; }
    }
    public enum Filter { EXACT, CHANGED, UNCHANGED, INCREASED, DECREASED }
    public interface Target {
        byte[] snapshot();
        void write(int offset, Kind kind, String value);
    }
    public static final class Hit {
        public final int offset;
        public final String value;
        Hit(int off, String str) { offset = off; value = str; }
    }
    private static final int MAX_CANDIDATES = 120_000;
    private final Target target;
    private final LinkedHashMap<Integer, Number> candidates = new LinkedHashMap<>();
    private final Map<Integer, String> frozen = new LinkedHashMap<>();
    private Kind kind;
    private boolean active;
    private boolean incomplete;

    public LiveMemoryScanner(Target target) { this.target = target; }
    public synchronized boolean isIncomplete() { return incomplete; }
    public synchronized Kind getKind() { return kind; }
    public synchronized int count() { return candidates.size(); }

    public synchronized int beginUnknown(Kind type) {
        reset(type);
        byte[] data = target.snapshot();
        for (int off = 0; off + kind.bytes <= data.length; off += kind.bytes) {
            if (candidates.size() == MAX_CANDIDATES) { incomplete = true; break; }
            candidates.put(off, load(data, off, kind));
        }
        active = true;
        return candidates.size();
    }
    public synchronized int beginExact(Kind type, String text) {
        reset(type);
        Number expected = parse(text, type);
        byte[] data = target.snapshot();
        for (int off = 0; off + kind.bytes <= data.length; off += kind.bytes) {
            Number n = load(data, off, kind);
            if (equal(n, expected, kind)) {
                if (candidates.size() == MAX_CANDIDATES) { incomplete = true; break; }
                candidates.put(off, n);
            }
        }
        active = true;
        return candidates.size();
    }
    public synchronized int refine(Filter filter, String exactText) {
        if (!active) throw new IllegalStateException("Najpierw rozpocznij skan");
        Number exact = filter == Filter.EXACT ? parse(exactText, kind) : null;
        byte[] now = target.snapshot();
        List<Integer> remove = new ArrayList<>();
        for (Map.Entry<Integer, Number> entry : candidates.entrySet()) {
            int offset = entry.getKey();
            if (offset + kind.bytes > now.length) { remove.add(offset); continue; }
            Number current = load(now, offset, kind);
            Number previous = entry.getValue();
            boolean keep;
            switch (filter) {
                case EXACT: keep = equal(current, exact, kind); break;
                case CHANGED: keep = !equal(current, previous, kind); break;
                case UNCHANGED: keep = equal(current, previous, kind); break;
                case INCREASED: keep = compare(current, previous, kind) > 0; break;
                case DECREASED: keep = compare(current, previous, kind) < 0; break;
                default: throw new AssertionError(filter);
            }
            if (keep) entry.setValue(current);
            else remove.add(offset);
        }
        for (Integer offset : remove) candidates.remove(offset);
        return candidates.size();
    }
    public synchronized List<Hit> getResults() {
        byte[] snap = target.snapshot();
        List<Hit> hits = new ArrayList<>();
        for (int off : candidates.keySet()) {
            if (off + kind.bytes <= snap.length)
                hits.add(new Hit(off, format(load(snap, off, kind), kind)));
        }
        return Collections.unmodifiableList(hits);
    }
    public synchronized String readAt(int offset) {
        assertCandidate(offset);
        byte[] snap = target.snapshot();
        return format(load(snap, offset, kind), kind);
    }
    public synchronized void edit(int offset, String text) {
        assertCandidate(offset);
        String checked = format(parse(text, kind), kind);
        target.write(offset, kind, checked);
    }
    public synchronized void freeze(int offset, String text) {
        assertCandidate(offset);
        String checked = format(parse(text, kind), kind);
        target.write(offset, kind, checked);
        frozen.put(offset, checked);
    }
    public synchronized boolean isFrozen(int offset) { return frozen.containsKey(offset); }
    public synchronized void unfreeze(int offset) { frozen.remove(offset); }
    public synchronized void applyFreezes() {
        if (!active) return;
        for (Map.Entry<Integer, String> e : frozen.entrySet())
            target.write(e.getKey(), kind, e.getValue());
    }
    private void assertCandidate(int offset) {
        if (!active || !candidates.containsKey(offset))
            throw new IllegalArgumentException("Wybierz adres z aktywnego wyniku skanu");
    }
    private void reset(Kind type) {
        active = false;
        candidates.clear();
        frozen.clear();
        incomplete = false;
        if (type == null) throw new IllegalArgumentException("Brak typu");
        kind = type;
    }
    static Number parse(String text, Kind kind) {
        try {
            if (text == null) throw new NumberFormatException("Pusta wartość");
            String s = text.trim();
            switch (kind) {
                case INT8: {
                    long v = Long.parseLong(s);
                    if (v < Byte.MIN_VALUE || v > Byte.MAX_VALUE) throw new NumberFormatException("Int8 poza zakresem");
                    return v;
                }
                case INT16: {
                    long v = Long.parseLong(s);
                    if (v < Short.MIN_VALUE || v > Short.MAX_VALUE) throw new NumberFormatException("Int16 poza zakresem");
                    return v;
                }
                case INT32: {
                    long v = Long.parseLong(s);
                    if (v < Integer.MIN_VALUE || v > Integer.MAX_VALUE) throw new NumberFormatException("Int32 poza zakresem");
                    return v;
                }
                case INT64: return Long.parseLong(s);
                case FLOAT: {
                    float v = Float.parseFloat(s);
                    if (!Float.isFinite(v)) throw new NumberFormatException("Wymagana skończona wartość");
                    return v;
                }
                case DOUBLE: {
                    double v = Double.parseDouble(s);
                    if (!Double.isFinite(v)) throw new NumberFormatException("Wymagana skończona wartość");
                    return v;
                }
                default: throw new AssertionError(kind);
            }
        } catch (NumberFormatException ex) { throw new IllegalArgumentException("Błędna wartość: " + text); }
    }
    private static Number load(byte[] data, int off, Kind kind) {
        ByteBuffer buffer = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        switch (kind) {
            case INT8: return (long)buffer.get(off);
            case INT16: return (long)buffer.getShort(off);
            case INT32: return (long)buffer.getInt(off);
            case INT64: return buffer.getLong(off);
            case FLOAT: return buffer.getFloat(off);
            case DOUBLE: return buffer.getDouble(off);
            default: throw new AssertionError(kind);
        }
    }
    private static String format(Number num, Kind kind) {
        return kind == Kind.FLOAT ? Float.toString(num.floatValue())
                : kind == Kind.DOUBLE ? Double.toString(num.doubleValue())
                : Long.toString(num.longValue());
    }
    private static boolean equal(Number a, Number b, Kind kind) {
        if (kind == Kind.FLOAT) return Float.compare(a.floatValue(), b.floatValue()) == 0;
        if (kind == Kind.DOUBLE) return Double.compare(a.doubleValue(), b.doubleValue()) == 0;
        return a.longValue() == b.longValue();
    }
    private static int compare(Number a, Number b, Kind kind) {
        if (kind == Kind.FLOAT) return Float.compare(a.floatValue(), b.floatValue());
        if (kind == Kind.DOUBLE) return Double.compare(a.doubleValue(), b.doubleValue());
        return Long.compare(a.longValue(), b.longValue());
    }
    /** Real direct/off-heap memory controlled exclusively by this debug app. */
    public static final class DemoTarget implements Target {
        private final ByteBuffer data = ByteBuffer.allocateDirect(16384).order(ByteOrder.LITTLE_ENDIAN);
        public DemoTarget() {
            data.putInt(0x100, 1250);
            data.putInt(0x200, 100);
            data.putFloat(0x240, 1.5f);
            data.putLong(0x300, 100_000L);
        }
        public synchronized int coins() { return data.getInt(0x100); }
        public synchronized void earnCoins(int amount) { data.putInt(0x100, coins() + amount); }
        public synchronized byte[] snapshot() {
            byte[] output = new byte[data.capacity()];
            ByteBuffer copy = data.duplicate(); copy.position(0); copy.get(output);
            return output;
        }
        public synchronized void write(int offset, Kind kind, String text) {
            if (offset < 0 || offset + kind.bytes > data.capacity() || offset % kind.bytes != 0)
                throw new IllegalArgumentException("Nieprawidłowy offset");
            Number n = parse(text, kind);
            switch (kind) {
                case INT8: data.put(offset, n.byteValue()); break;
                case INT16: data.putShort(offset, n.shortValue()); break;
                case INT32: data.putInt(offset, n.intValue()); break;
                case INT64: data.putLong(offset, n.longValue()); break;
                case FLOAT: data.putFloat(offset, n.floatValue()); break;
                case DOUBLE: data.putDouble(offset, n.doubleValue()); break;
                default: throw new AssertionError(kind);
            }
        }
    }
}
