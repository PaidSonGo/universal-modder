package pl.sandboxreplylab;

import java.util.Locale;
import java.util.regex.Pattern;

/**
 * A developer-owned, declarative UI navigation scenario. It is NOT an APK binary patcher.
 * The owner must integrate the exported plan into their own app's debug build/rebuild pipeline.
 */
public final class FlowPlan {
    private static final Pattern IDENTIFIER = Pattern.compile("[a-zA-Z][a-zA-Z0-9_.-]{0,95}");
    private static final Pattern PACKAGE_NAME = Pattern.compile("[a-zA-Z][a-zA-Z0-9_]*(?:\\.[a-zA-Z][a-zA-Z0-9_]*)+");
    private static final String[] PROTECTED_TERMS = {
        "billing", "payment", "purchase", "checkout", "receipt", "entitle", "license", "licence", "subscription", "premium", "paywall", "reward", "currency", "wallet", "balance", "ads", "admob", "advert", "signature", "integrity"
    };

    public final String packageName, fromScreen, eventName, toScreen, note;
    private FlowPlan(String pkg, String from, String event, String to, String description) {
        this.packageName=pkg;
        this.fromScreen=from;
        this.eventName=event;
        this.toScreen=to;
        this.note=description;
    }

    public static FlowPlan create(String pkg, String from, String event, String to, String note) {
        if (pkg == null || !PACKAGE_NAME.matcher(pkg.trim()).matches() || pkg.length() > 190)
            throw new IllegalArgumentException("Podaj poprawny identyfikator własnej aplikacji (np. pl.example.debug).");
        checkRoute(from, "Ekran początkowy");
        checkRoute(event, "Zdarzenie");
        checkRoute(to, "Ekran docelowy");
        if (note != null && note.length() > 500)
            throw new IllegalArgumentException("Notatka nie może przekraczać 500 znaków.");
        return new FlowPlan(pkg.trim(), from.trim(), event.trim(), to.trim(), note==null?"":note);
    }
    private static void checkRoute(String value, String label) {
        if (value == null || !IDENTIFIER.matcher(value.trim()).matches())
            throw new IllegalArgumentException(label + ": użyj liter, cyfr i znaków ._- (maks. 96). ");
        String normalized=value.toLowerCase(Locale.ROOT);
        for (String term:PROTECTED_TERMS) {
            if (normalized.contains(term))
                throw new IllegalArgumentException("Reguły zakupów, licencji, reklam i ekonomii nie są obsługiwane przez edytor nawigacji.");
        }
    }
    public String simulate(String currentScreen, String event) {
        return simulate(currentScreen, event, currentScreen);
    }
    public String simulate(String currentScreen, String event, String originalDestination) {
        if (fromScreen.equals(currentScreen) && eventName.equals(event)) return toScreen;
        return originalDestination;
    }
    public String toJson() {
        return "{\n  \"schemaVersion\":1,\n  \"mode\":\"developer-navigation-only\",\n  \"packageName\":\""+escape(packageName)
                +"\",\n  \"fromScreen\":\""+escape(fromScreen)
                +"\",\n  \"eventName\":\""+escape(eventName)
                +"\",\n  \"toScreen\":\""+escape(toScreen)
                +"\",\n  \"note\":\""+escape(note)
                +"\",\n  \"buildNote\":\"Projekt konfiguracyjny, nie zmodyfikowany APK. Po przebudowie użyj narzędzia podpisującego i zweryfikuj SHA-256 oryginalnego certyfikatu.\"\n}";
    }
    private static String escape(String text) {
        StringBuilder out=new StringBuilder(text.length()+10);
        for(int i=0;i<text.length();i++) {
            char c=text.charAt(i);
            if (c=='"') out.append("\\\"");
            else if(c=='\\') out.append("\\\\");
            else if(c=='\n') out.append("\\n");
            else if(c=='\r') out.append("\\r");
            else if(c=='\t') out.append("\\t");
            else if(c<32) out.append(String.format(Locale.ROOT,"\\u%04x",(int)c));
            else out.append(c);
        }
        return out.toString();
    }
}
